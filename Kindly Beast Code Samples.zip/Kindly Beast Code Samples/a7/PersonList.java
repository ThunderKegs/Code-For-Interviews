/**
 * COMP1406 - W16 - Assignment 7.
 *
 * This class implements a list of people (Person objects)
 * using a linked list.
 *
 * @author <Mackenzie Yendall>
 * @since <March.13th, 2016>
 * @custom.citations <Hinek, J. "Lectures Notes for COMP1406C - Introduction to Computer Science II" [PDF documents].
Retrieved from cuLearn: https://www.carleton.ca/culearn/ (Winter 2016).>
 */



public class PersonList{
  /* ----------------------------------------------- */
  /* Attributes                                      */
  /* ----------------------------------------------- */

  /* head is the first node in the linked list */
  private Node head;


  /* ----------------------------------------------- */
  /* constructors                                    */
  /* ----------------------------------------------- */

  /** Creates an empty list. */
  public PersonList(){ }

  /** Creates a list with a single person.
    *
    * @param p is a Person that will be the only person in the new list
    */
  public PersonList(Person p){
    this.head=new Node(p);//initializes the head node using the parameter "p"
  }


  /* ----------------------------------------------- */
  /* Methods                                         */
  /* ----------------------------------------------- */

  /**
   * The size of the list.
   *
   * This is the number of people in the list. If a person
   * is in the list more than once they are counted each time they appear.
   * For example, the list [sam(12), sam(12), sam(12)] has size 3, even though
   * it is the same person listed three times.
   *
   * @return the number of people in the list.
   */
  public int size(){
    int count = 0;//size counter
    Node currentNode = (this.head);//creates a new node equal to the current head node
    while(currentNode!=null){//loops until the current node does not exist
      count++;//increases the count whenever a loop is completed
      currentNode=currentNode.getNext();//moves to the next node
    }
    return count;//returns the size of list
  }

  /**
   * Add a person to the front of the list.
   *
   * After the method is called, this.head should reference this
   * newly added person.
   *
   * @param p is a person to be added to the front of the list.
   */
  public PersonList add(Person p){
    if((this.head)==null){
      head = new Node(p);
    }
    else{
    Node node = (new Node(p));
    Node tempNode = head;
    this.head = node;
    head.setNext(tempNode);
    }
    return this;
    }

  /**
   * Add a person to a given position in the list.
   *
   * The indexing is the same as if the list were an array. The first element
   * is at position 0, the second element is at position 1, ..., the last
   * element is at position this.size()-1.
   *
   * When adding a person at position M, all people in the original list at positions
   * M, M+1, ..., size()-1, will be shifted over one place (to the right) in the list.
   * If the list was originally [sam(12), joe(17)] and add is called with person
   * ellen(13) at position 1, then this list becomes [sam(12), ellen(13), joe(17)]
   *
   * @param p is a person to add to the list.
   * @param position is the position in the list to add (insert) this person.
   * Positon 0 is the front of the list, position 1 is the 2nd element, etc.
   */
  private Node getAtPosition(int pos){//gets the node at the input position
    Node node = head;//makes a new node that is equal to head
    for(int i=0; i<pos; i++){//loops through the list until the position is reached
      node=(node.getNext());
    }
    return node;//returns the node in question
  }

  public PersonList add(Person p, int position){
    if(position==0){
      this.add(p);
    }
    else{
    Node newNode = new Node(p);
    Node node = (getAtPosition(position));
    Node previousNode = (getAtPosition(position-1));
    previousNode.setNext(newNode);
    newNode.setNext(node);
    }
    return this;
  }

  /**
   * Adds several people to the list starting at a given position.
   *
   * For example, if this is the list [cat, dog, eel] and people is
   * the list [one, two , three], then add(people, 0) would change
   * this be [one, two, three, cat, dog, eel], while add(people,1)
   * would change this list to be [cat, one, two, three, dog, eel].
   *
   * @param people is a list of people to add to the current list.
   * @param startPosition is the position in the current list that the new
   * list is added (inserted). The order of the elements in the new list remain
   * the same.
   */
  public PersonList add(PersonList people, int startPosition){//come back to this, may be able to do something better with a nested for loop
    int size = (people.size());
    if(startPosition==0){//alternate case for the case where the start position is zero
      for(int i=(size-1); i>-1; i--){//loops through the people list backwards, repeatedly calling the add function in the process
        this.add(people.personAt(i));
      }
      return this;
    }
    else{
    Node endLinkNode = (this.getAtPosition(startPosition));
    Node endNode = (people.getAtPosition(size-1));//last node in the people list
    endNode.setNext(endLinkNode);//links the end of the people list to the appropriate location in this list
    Node startLinkNode = (getAtPosition(startPosition-1));
    Node startNode = (people.getAtPosition(0));//gets the first node in the people list
    startLinkNode.setNext(startNode);//links the start of the people list to the appropriate location in the list
    }

    return this;// returns this list
  }

  /**
   * Finds the position in the list where a given person is.
   *
   * @param p is a person that may or may not be in the list.
   * @return the index position (starting with 0) in the list where the
   * first instance of of person p is located. (A person may be in the list
   * more than once.)
   * If the person is not in the list returns -1.
   */
  public int findPosition(Person p){
    String testName = p.getName();
    Node tempNode = head;
    for(int i=0; i<(this.size()); i++){//loops through the list until a person with the same name as p is found
      if((tempNode.getPerson().getName())==testName){
        return i;//returns the index where a matching name is found
      }
      tempNode = (tempNode.getNext());
    }
    return -1;
  }

  /**
   * Finds the person at a given index in the list
   *
   * You can assume that 0 <= position < this.sise()
   *
   * @param position is a position in the list. It must satisfy
   * 0 <= position < this.size().
   * @return the person located at the specified position in the list.
   * The method does NOT remove the person from the list.
   */
  public Person personAt(int position){
    Person person = ((getAtPosition(position)).getPerson());
    return person;
  }

  /**
   * Removes a person from a given position in the list.
   *
   * @param position is the index in the list that we wish to remove a person.
   * @return the person that is removed from the list.
   */
  public Person remove(int position){
    if(getAtPosition(position)!=null){//checks to make sure that the index contains a person
      Person person = (personAt(position));//stores the person at position
      if(position==0){//if statement to deal with a case where position=0
      this.head = this.head.getNext();//sets the head node equal to the node right after head
      return person;
      }
          Node previous = (getAtPosition(position-1));//finds the node before the current node
          previous.setNext((getAtPosition(position)).getNext());/*changes the next value of the previous node to be
          the node after the current node*/
          return person;
    }
    return null;//if the index does not contain a person, returns a null pointer
  }

  /**
   * remove several people from the list and returns them as a list of people.
   *
   * @param startPosition is starting position (index in the list)
   * of the first person to remove (inclusive).
   * @param endPosition is the ending position (index in the list or one beyond) of the
   * last person EXCLUSIVE.
   * @return a list of people from index position startPosition to endPosition - 1,
   * in the same order, as this list before the method is called.
   * The people returned are also removed from the current list.
   */
  public PersonList remove(int startPosition, int endPosition){
    PersonList removedPeople = new PersonList();//creates an empty personList
    for(int i = (endPosition-1); i>=(startPosition); i--){
      removedPeople.add(this.personAt(i));//populates removedPeople with all people that would be removed
    }
    Node start = this.getAtPosition(startPosition-1);//finds the node right before the start position
    Node end = this.getAtPosition(endPosition);//finds the node right before the end position
    start.setNext(end);//links the nodes at the start and end position, disregarding all nodes in between
    if(startPosition==0){//condition to deal with a start position equal to zero
      head = end;
    }
    return removedPeople;
  }

  /**
   * Checks if this list is the "same" and another list.
   *
   * Two lists are the same if they have the same people in the same order.
   * Two people are the same if they have the same name (ignoring case) and
   * the same age. An empty list is not the same as null.
   *
   * @param otherList is a list of people.
   * @return true if this list contains the same people (none less or more) as the people
   * in otherList and in the exact same order.
   *
   * Returns false otherwise.
   */
  public boolean sameAs(PersonList otherList){
    Node otherHead = (otherList.getAtPosition(0));
    Node thisHead = head;
    int size = this.size();
    int otherSize = (otherList.size());
    if(size!=otherSize){
      return false;
    }
    for(int i=0; i<size; i++) {
      if((thisHead.getPerson().getName())!=(otherHead.getPerson().getName())){
        return false;
    }
  }
    return true;
}

  /**
   * A list of all people in this list that have age strictly greater than some cutoff age.
   *
   * @param age the cutoff age for the output list.
   * @return a list of all people in this list that have age strictly greater than the input cutoff age.
   * The order of the people in the returned list is the same as in this list.
   * This method does NOT remove any people from this list.
   */
  public PersonList olderThan(int age){//go through this code a bit more, it may have bugs
    Node currentNode = head;
    PersonList olderPeople = new PersonList(currentNode.getPerson());
    for(int i=0; i<(size()); i++){
      if((currentNode.getPerson().getAge())>age){
            olderPeople.add(currentNode.getPerson());
          }
          currentNode=(currentNode.getNext());
        }
    return olderPeople;
  }

  /**
   * A String representation of this list.
   *
   * If this list consists of the people
   * [cat age 12, dog age 17, eel age 3], the output string should look identical
   * (without the double quotes) to "[cat(12), dog(17), eel(3)]". An empty list will
   * return "[]". Be sure not to have a trailing comma after the last person
   * in the list.
   *
   * @return a string representation of this list.
   */
  @Override
  public String toString(){
    String peopleString = "[";
    for(int i=0; i<(this.size()); i++){
      int tempAge = (getAtPosition(i).getPerson().getAge());
      String tempName = (getAtPosition(i).getPerson().getName());
      peopleString+=tempName+"("+tempAge+")";
      if((getAtPosition(i).getNext())==null){
        peopleString+="]";
        return peopleString;
      }
      else{
        peopleString+=", ";
      }
    }
      return "Nothing to see here...";
  }
}

