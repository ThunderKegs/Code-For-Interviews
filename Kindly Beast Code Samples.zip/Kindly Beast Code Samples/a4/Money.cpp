// ---------------------------------------------------------------------------
// In this .cpp file you will provide the source code for all
// functions, constructors and method specified in A4Tyope,h that are not yet defined.
// You are allowed to write helper functions but are not allowed to change the
// class definitions.
//
// Student Name: Mackenzie Yendall
// Student Number: 101007018
//
// References: Spraul, V. Anton.(2012). Think Like a Programmer(pp.82-85).
//
// ---------------------------------------------------------------------------



#include "A4Types.h"
#include <iostream>


// Note: When defining method behaviour in C++ class
//       in a different location than the actual class
//       definition (.h file) we need to specify not only the
//       name of the function but also which class it belongs to.
//       We use Return_Type Class_Name::Method_Name to do this.


Money::Money(){//
numDollars=0;    // number of dollars is set to 0
numQuarters=0;   // number of quarters is set to 0
numDimes=0;      // number of dimes is set to 0
numNickels=0;    // number of nickels is set to 0
numPennies=0;    // number of pennies is set to 0
}

Money::Money(unsigned int dollars, unsigned int cents){
    numDollars=dollars;//sets the numDollars variable in the current object equal to dollars
    numQuarters=0;   // number of quarters is set to 0
    numDimes=0;      // number of dimes is set to 0
    numNickels=0;
    numPennies=cents;//sets the numPennies variable in the current object equal to cents
    // Money constructor (two arguments)
}

Money::Money(unsigned int dd, unsigned int q, unsigned int d, unsigned int n, unsigned int p){
numDollars=dd;    // number of dollars
numQuarters=q;   // number of quarters (25 cents)
numDimes=d;      // number of dimes (10 cents)
numNickels=n;    // number of nickels (5 cents)
numPennies=p;    // number of pennies (1 cents)
    // Money constructor (five arguments)
}

// getters provided for you
// Note that we still need to specify which class the
// methods belong to.
unsigned int Money::getDollars(){  return numDollars;}
unsigned int Money::getQuarters(){ return numQuarters;}
unsigned int Money::getDimes(){    return numDimes;}
unsigned int Money::getNickels(){  return numNickels;}
unsigned int Money::getPennies(){  return numPennies;}

unsigned int Money::getCents(){//multiplies each coin in the current object by their respective value in cents and returns the sum of those values
return(((getQuarters()) * 25)+((getDimes()) * 10)+((getNickels()) * 5)+(getPennies()));
}

// setter functions
void Money::addMoney(Money m){//adds the respective elements from the input object to their corresponding values in the current object
numDollars+=m.numDollars;
numQuarters+=m.numQuarters;
numDimes+=m.numDimes;
numNickels+=m.numNickels;
numPennies+=m.numPennies;
}
void Money::addDollars(unsigned int d){//adds the input value to the numDollars variable in the current object
numDollars+=d;
}
void Money::addQuarters(unsigned int q){//adds the input value to the numQuarters variable in the current object
numQuarters+=q;
}
void Money::addDimes(unsigned int d){//adds the input value to the numDimes variable in the current object
numDimes+=d;
}
void Money::addNickels(unsigned int n){//adds the input value to the numNickels variable in the current object
numNickels+=n;
}
void Money::addPennies(unsigned int p){//adds the input value to the numPennies variable in the current object
numPennies+=p;
}
void Money::addCents(unsigned int c){
addPennies(c);
}

// other methods
unsigned int Money::numberOfCoins(){
return(numQuarters+numDimes+numNickels+numPennies);//tallies and returns the numbers of coins in the current objects
}
void Money::leastCoins(){
    while(numPennies>=5){//checks if there are at least 5 pennies in the current object, repeating until there are less than 5
        numPennies=numPennies-5;//subtracts 5 from the number of pennies
        addNickels(1);//adds 1 to the number of nickels
    }
    while(numNickels>=2){//checks if there are at least 2 nickels in the current object, repeating until there are less than 2
        numNickels=numNickels-2;//subtracts 2 from the number of nickels
        addDimes(1);//adds 1 to the number of dimes
    }
    while(numDimes>=2&&numNickels>=1){
        numDimes=numDimes-2;//subtracts 2 from the number of dimes
        numNickels=numNickels-1;//subtracts 1 from the number of nickels
        addQuarters(1);//adds 1 to the number of quarters
    }
}



//
// Functions using Money objects for Exercise 4
//

Money* makeChange(Money& cost, Money& paid){
if(paid.getCents()<cost.getCents()){//if the value of paid cents is less that the cents required
    paid.addDollars(-1);//subtract 1 from the paid dollars
    paid.addCents(100);//add 100 to the paid cents, resulting in the same net value
}
if(paid.getDollars()>=cost.getDollars()){
    int dollars=(paid.getDollars())-(cost.getDollars());//creates a variable equal to the difference between paid dollars and the dollars required
    int cents=(paid.getCents()-cost.getCents());//creates a variable equal to the difference between paid cents and the cents required
    Money change(dollars, cents);//creates a new money object using the previous values
    change.leastCoins();// optimizes the number of coins in the change
    Money *changePtr;//creates a pointer for a money object
    changePtr = &change;//sets "changePtr" to point to the address of change
    return changePtr;//returns the pointer
}

else{
    return NULL;//if none of the above conditions are valid, return a null pointer
}
}
Money* makeChangeNoPennies(Money& cost, Money& paid){
if(paid.getCents()<cost.getCents()){
    paid.addDollars(-1);
    paid.addCents(100);
}
if(paid.getDollars()>=cost.getDollars()){
    int dollars=(paid.getDollars())-(cost.getDollars());
    int cents=(paid.getCents()-cost.getCents());
    if((cents%5)!=0){
        int temp=cents;
        while((temp-5)>0){
            temp-=5;
        }
        cents-=temp;
        if((temp==3)||(temp==4)){
            cents+=5;
        }
    }
    Money change(dollars, cents);
    change.leastCoins();
    Money *changePtr;
    changePtr = &change;
    return changePtr;
}

else{
    return NULL;
}
}




