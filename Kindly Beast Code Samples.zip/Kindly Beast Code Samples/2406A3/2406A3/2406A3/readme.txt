Launch Command:
node chatServerSocketIo_final.js


OS Used:
Windows 10
Browser Used:
Google Chrome

Notes: I wrote this chatroom program back in early 2017, meaning that a lot has changed in terms of my programming
       capabilites since then. The primary changes I would makes to this project would be to switch from a socket based
       IO model to something more modern, efficient and lightweight.