// Name of Author: Mackenzie Yendall
// Student ID: 101007018
// SocketIO based chat room. Extended to not echo messages to the client that sent them.
// In the future, this program should be modified to not make use of Socket.IO, as socket based systems outdated and not efficient.
// Added functionality includes blocking communications and sending private messages to specified users, using a click-based html list.

var http = require('http').createServer(handler);
var io = require('socket.io')(http);
var fs = require('fs');

http.listen(2406);//listens to the local port 2406. This port is likely inactive, as this program was written in 2016.

console.log("Chat server listening on port 2406");


function handler(req,res){//a simple function handler for user commands
	fs.readFile("./files/chatRoom_final.html", function(err,data){
		if(err){//simple error case handler
			res.writeHead(500);
			return res.end("An error has occured while loading chatRoom.html");
		}else{
			res.writeHead(200);
			res.end(data);
		}
	});
};
var clients = [];
var numClients = 0;
io.on("connection", function(socket){//establishes a connection with the server and allows the user to input a number of commands.
	var username;
	console.log("A connection has been established.");
	console.log(numClients);
	socket.on("intro",function(data){//establishes a user as part of the server and grants them access to the available commands that follow
		console.log("Intro");
		socket.username = data;
		clients.push(socket);
		var users = getUserList();
		socket.blockedUsers = [];
		console.log(users + " " + users.length);
		socket.broadcast.emit("userList", {users:users});
		socket.emit("userList", {users:users});
		socket.broadcast.emit("message", timestamp()+": "+socket.username+" has entered the chatroom.");
		socket.emit("message","Welcome, "+socket.username+".");
	});
		
	socket.on("message", function(data){//allows the user to send a message to the chatroom.
		console.log("message received: " + data);
		socket.broadcast.emit("message", timestamp() + ", " + socket.username + ": " + data);
		
	});

	socket.on("disconnect", function(){//handles user's disconnecting from the server
		console.log(socket.username+" has disconnected");
		removeUser(socket.username);
		var users = getUserList();
		io.emit("userList", {users:users});
		io.emit("message", timestamp()+": "+socket.username+" has disconnected.");
	});
	
	
	socket.on("blockUser", function(data){//allows a user to block communications with users of a selected username, or unblock them if they were previously blocked
		console.log("blockUser request on " + data.username);
		var index = findUser(data.username).blockedUsers.indexOf(socket.username);
		console.log(index);
		if(index<0){
			findUser(data.username).blockedUsers.push(socket.username);
			socket.emit("message", data.username + " has been blocked.");
		}else{
			findUser(socket.username).blockedUsers.splice(index, 1);
			socket.emit("message", data.username + " has been unblocked.");
		}
		console.log(findUser(socket.username).blockedUsers);
	});
	
	socket.on("privateMessage", function(data){//allows a user to send a private message to the selected user.
		console.log("Private message to " + data.username + ": "+ data.message);
		if(!checkBlock(data.username, findUser(socket.username).blockedUsers))
		{
			findUser(data.username).emit("privateMessage", 
			{message: socket.username + " says: " +data.message, username: socket.username});
		}
	});
});

function timestamp(){//outputs a timestamp as a string
	return new Date().toLocaleTimeString();
}

function getUserList(){//lists known users that are connected to the server.
    var tempArray = [];
	var i=0;
	while(i<clients.length){
		tempArray.push(clients[i].username);
		i++;
	}
    console.log(tempArray);
    return tempArray;
}

function findUser(username){// a simple search function for the user array
	var tempArray = [];
	tempArray = getUserList();
    	var index = tempArray.indexOf(username);
    	console.log(index);
	var user = clients[index];
	return user;
}

function removeUser(username){//deletes a username from the user array
	var tempArray = [];
	tempArray = getUserList();
    var index = tempArray.indexOf(username);
    console.log(index);
    if (0<=index) {
    	clients.splice(index, 1);
	}
}

function checkBlock(currentuser, blockedusers){//displays users that have been blocked by the current user.
	var i=0;
	while(i<blockedusers.length){
		if(currentuser==blockedusers[i]){
			console.log(blockedusers[i]);
			return true;
		}
		i++;
	}
}