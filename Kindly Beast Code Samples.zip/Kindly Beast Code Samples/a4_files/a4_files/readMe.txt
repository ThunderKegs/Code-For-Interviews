Name: Mackenzie Yendall
Student ID: 101007018

COMP 2406 - Assignment 4 README

This application was built on Windows 10

To run this program, extract and navigate to the Assignment 4 Directory in terminal and run 'node server.js'.
The server will then be listening at port 2406. To reach the program, first open the terminal/command prompt
and type: mongod
This will launch the mongodb server, and type http://localhost:2406/.
Note that you will need access to both the mongodb and node.js software in order to run this program.

The zip file comes with a node_modules folder, a public folder, the views folder containing pug files,
a package.json file and the server.js server file.
The views folder contains index.pug file which is the file being loaded at localhost:2406.

Successful testing of this program was done in Google Chrome.

NOTE : This program was written 2 years ago and relies on a server that may no longer be active.
       The program itself still functions on any similar mongodb server with a few of my own modifications.

