// Name of Author: Mackenzie Yendall
// Student ID: 101007018
// Some portions of this code were taken from the express and mongoDB lectures, as well as some inspiration from tutorial 10. As a result, there are many shared variables and ideas.
// This program allows for the access and modification of recipes that are stored on a mongo database through a pug-generated html page
// The style document is a direct, one to one replication of the example page shown in the assignment description
var express = require('express');
var app = express();
var parser = require('body-parser');
var MongoClient = require('mongodb').MongoClient;

app.set('views','./views'); //sets the default pug directory
app.set('view engine','pug'); //view engine as pug code

app.use(parser.urlencoded({extended:true})); // support for encoded bodies
app.use(parser.json()); // support for json encoded bodies

app.use(function(req,res,next){
  console.log(req.method+" request for "+req.url);
  next(); //continues the signal
});

app.get(["/","/index"],function(req,res) { //renders the html page upon connecting to localhost:2406
  res.render('index');
});

app.get('/recipes', function (req, res) { //functions gets the recipe
  MongoClient.connect("mongodb://localhost:27017/recipeDB",function(err,db){
    if (!err) { //if there is not an error use a cursor to append all recipe name to an array before sending it
	  var recipes = db.collection("recipeCollection");
      recipeList = [];
      var cursor = recipes.find(); //locates the recipes
      cursor.each(function(err, recipe){ //for each recipe
        if(err){res.sendStatus(500);}
        else if (null==recipe) { //if end of the list has been reached
          console.log("recipeList is ", recipeList);
          res.send({names : recipeList}); //sends the signal
          db.close();
        }else{recipeList.push(recipe.name);} //appends the recipe name onto the end of the array
      });
    }else{//if there is an error
      console.log("FAILED TO CONNECT TO THE DATABASE!");
      res.sendStatus(500);
      db.close();
    }
  });
});

app.get("/recipe/:name", function(req,res) { //retrieves the selected recipe
  MongoClient.connect("mongodb://localhost:27017/recipeDB",function(err,db){
    if(!err){ //{name:String, duration:Number, ingredients:[StringArray], directions:[StringArray], notes:String}
	  var recipes = db.collection("recipeCollection");
	  nameReq = req.params.name;
	  console.log("req params is", req.params.name);
	  var cursor = recipes.find();
	  cursor.each(function(err, recipe){
	    if(err){res.sendStatus(500);}
		if(null==recipe){
	      db.close(); //close and send nothing
	    }else if(recipe.name === req.params.name){//if the name of the recipe in question and that of the current index match
	      res.send(recipe); //send back the recipe
	      db.close();
	    }
	  });
    }else{
      console.log("FAILURE TO CONNECT TO THE DATABASE");
      res.sendStatus(500);
      db.close();
	};
  });
});

app.post("/recipe", function(req, res) { //post a recipe to the collection
  MongoClient.connect("mongodb://localhost:27017/recipeDB",function(err,db){
    if(!err) {
	  var recipes = db.collection("recipeCollection"); //access the collection
      if (req.body.name === "") {db.close();}//if recipe name is not available, do not add it to the collection
      //upsert the recipe into collection (if it exists, modify it. otherwise, add it to the collection)
      recipes.update({name : req.body.name}, req.body, {upsert: true}, function (err, recipe) {
        if(!err){res.sendStatus(200);}//updates the current recipe list
        else{
		  console.log("FAILURE TO CONNECT TO THE DATABASE");
          res.sendStatus(500);
          db.close();
		}
      });
    }else{
	  console.log("FAILURE TO CONNECT TO THE DATABASE");
	  res.sendStatus(500);
	  db.close();
    }
  });
});

app.use(express.static("./public")); //static files would be in the ./public folder. This is required for express.
app.listen(2406, function(){console.log("Server Online (port 2406)");}); //starts listening on port 2406
